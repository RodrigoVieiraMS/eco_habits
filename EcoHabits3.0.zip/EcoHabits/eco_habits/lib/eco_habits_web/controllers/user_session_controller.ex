defmodule EcoHabitsWeb.UserSessionController do
  use EcoHabitsWeb, :controller

  alias EcoHabits.Accounts
  alias EcoHabitsWeb.UserAuth

 def create(conn, %{"_action" => "confirmed"} = params) do
    create(conn, params, "User confirmed successfully.")
  end

  # Essa é a função pública padrão que o formulário de login vai chamar
  def create(conn, %{"user" => _user_params} = params) do
    create(conn, params, "Bem-vindo de volta!")
  end

  # Caso caia aqui sem o mapa de "user", serve de fallback
  def create(conn, params) do
    create(conn, params, "Welcome back!")
  end

  # Esta é a função privada que REALMENTE faz o login (Email + Password login)
  defp create(conn, %{"user" => user_params}, info) do
    %{"email" => email, "password" => password} = user_params

    if user = Accounts.get_user_by_email_and_password(email, password) do
      conn
      |> put_flash(:info, info)
      # Chamamos o log_in_user normal. A função original dele no seu user_auth.ex
      # vai cuidar do redirecionamento para o ~p"/dashboard" que configuramos antes!
      |> UserAuth.log_in_user(user, user_params)
    else
      # Se o login falhar, joga o e-mail no flash para persistência (exigência do PDF)
      conn
      |> put_flash(:error, "E-mail ou senha inválidos")
      |> put_flash(:email, String.slice(email, 0, 160))
      # Corrigido para underline para bater com o seu router.ex
      |> redirect(to: ~p"/users/log_in")
    end
  end
  def update_password(conn, %{"user" => user_params} = params) do
    user = conn.assigns.current_scope.user
    true = Accounts.sudo_mode?(user)
    {:ok, {_user, expired_tokens}} = Accounts.update_user_password(user, user_params)

    # disconnect all existing LiveViews with old sessions
    UserAuth.disconnect_sessions(expired_tokens)

    conn
    |> put_session(:user_return_to, ~p"/users/settings")
    |> create(params, "Password updated successfully!")
  end

  def delete(conn, _params) do
    conn
    |> put_flash(:info, "Logged out successfully.")
    |> UserAuth.log_out_user()
  end
end
