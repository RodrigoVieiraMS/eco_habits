defmodule EcoHabitsWeb.UserLoginLive do
  use EcoHabitsWeb, :live_view

  def render(assigns) do
  ~H"""
  <div class="mx-auto max-w-sm mt-12 bg-blue-950 p-8 rounded-xl shadow-sm border border-blue-900">
    <div class="text-center mb-6">
      <h2 class="text-2xl font-bold tracking-tight text-white">Entrar no EcoHabits</h2>
      <p class="mt-2 text-sm text-blue-200">
        Não possui conta?
        <.link navigate={~p"/users/register"} class="font-semibold text-emerald-400 hover:underline">
          Registrar-se
        </.link>
      </p>
    </div>

    <.form :let={f} for={@form} id="login_form" action={~p"/users/log-in"} phx-update="ignore" class="space-y-6">
      <div>
        <label class="block text-sm font-semibold text-blue-100 mb-1">E-mail</label>
        <input type="email" name="user[email]" value={@form[:email].value} required class="w-full rounded-lg border border-blue-700 bg-blue-900 px-3 py-2 text-white placeholder-blue-400 shadow-sm focus:border-emerald-500 focus:ring-emerald-500 sm:text-sm" />

        <div class="flex space-x-2 mt-2">
          <button type="button" phx-click="clear_email" class="text-xs text-blue-400 hover:text-red-400 underline">
            Limpar e-mail salvo
          </button>
          <span class="text-xs text-blue-700">|</span>
          <button type="button" phx-click="switch_account" class="text-xs text-blue-400 hover:text-emerald-400 underline">
            Trocar Conta
          </button>
        </div>
      </div>

      <div>
        <label class="block text-sm font-semibold text-blue-100 mb-1">Senha</label>
        <input type="password" name="user[password]" required class="w-full rounded-lg border border-blue-700 bg-blue-900 px-3 py-2 text-white shadow-sm focus:border-emerald-500 focus:ring-emerald-500 sm:text-sm" />
      </div>

      <div class="flex items-center">
        <input type="checkbox" name="user[remember_me]" id="remember_me" class="h-4 w-4 rounded border-blue-700 text-emerald-600 focus:ring-emerald-500" />
        <label for="remember_me" class="ml-2 block text-sm text-blue-200">Mantenha-me conectado</label>
      </div>

      <div>
        <button type="submit" class="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-emerald-700 hover:bg-emerald-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500">
          Entrar
        </button>
      </div>
    </.form>
  </div>
  """
end

  def mount(_params, _session, socket) do
    persistent_email = Phoenix.Flash.get(socket.assigns.flash, :email) || ""
    form = to_form(%{"email" => persistent_email}, as: "user")

    {:ok, assign(socket, form: form, persistent_email: persistent_email), temporary_assigns: [form: nil]}
  end

  def handle_event("clear_email", _params, socket) do
    form = to_form(%{"email" => ""}, as: "user")
    {:noreply, assign(socket, form: form)}
  end

  def handle_event("switch_account", _params, socket) do
    form = to_form(%{"email" => ""}, as: "user")
    {:noreply, assign(socket, form: form)}
  end
end
