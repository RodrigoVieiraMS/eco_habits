defmodule EcoHabitsWeb.Router do
  use EcoHabitsWeb, :router

  import EcoHabitsWeb.UserAuth

  pipeline :browser do
    plug :accepts, ["html"]
    plug :fetch_session
    plug :fetch_live_flash
    plug :put_root_layout, html: {EcoHabitsWeb.Layouts, :root}
    plug :protect_from_forgery
    plug :put_secure_browser_headers
    plug :fetch_current_scope_for_user
  end

  pipeline :api do
    plug :accepts, ["json"]
  end

  scope "/", EcoHabitsWeb do
    pipe_through :browser

    get "/", PageController, :home
  end

  # Enable LiveDashboard and Swoosh mailbox preview in development
  if Application.compile_env(:eco_habits, :dev_routes) do
    import Phoenix.LiveDashboard.Router

    scope "/dev" do
      pipe_through :browser

      live_dashboard "/dashboard", metrics: EcoHabitsWeb.Telemetry
      forward "/mailbox", Plug.Swoosh.MailboxPreview
    end
  end

  ## ———————————————————————————————————————————————————————————————————
  ## ROTAS DE AUTENTICAÇÃO E PAINEL (PADRÃO DO SEU PROJETO)
  ## ———————————————————————————————————————————————————————————————————

  # ESCOPO 1: Páginas que EXIGEM login (Dashboard e seu Perfil Módulo A)
  scope "/", EcoHabitsWeb do
    pipe_through [:browser, :require_authenticated_user]

    live_session :require_authenticated_user,
      on_mount: [{EcoHabitsWeb.UserAuth, :require_authenticated_user}] do

      live "/dashboard", DashboardLive, :index
      live "/users/profile", UserProfileLive, :index

      live "/users/settings", UserLive.Settings, :edit
      live "/users/settings/confirm-email/:token", UserLive.Settings, :confirm_email
    end

    post "/users/update-password", UserSessionController, :update_password
  end

  # ESCOPO 2: Páginas de Autenticação (Acessíveis para Visitantes)
  scope "/", EcoHabitsWeb do
    pipe_through [:browser]

    live_session :current_user,
      on_mount: [{EcoHabitsWeb.UserAuth, :mount_current_scope}] do

      live "/users/register", UserLive.Registration, :new
      live "/users/log_in", UserLoginLive, :new
      live "/users/log-in/:token", UserLive.Confirmation, :new
    end

    post "/users/log-in", UserSessionController, :create
    delete "/users/log-out", UserSessionController, :delete
  end
end
