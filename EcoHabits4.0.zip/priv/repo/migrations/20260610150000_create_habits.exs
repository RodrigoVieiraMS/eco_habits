defmodule EcoHabits.Repo.Migrations.CreateHabitsTableForModuleB do
  use Ecto.Migration

  def change do
    create table(:habits) do
      add :name, :string, null: false
      add :description, :text, null: false
      add :category, :string, null: false
      add :points, :integer, null: false

      add :user_id,
          references(:users, on_delete: :delete_all),
          null: false

      timestamps()
    end

    create index(:habits, [:user_id])
  end
end