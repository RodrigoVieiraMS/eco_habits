defmodule EcoHabits.Habits.Habit do
  use Ecto.Schema
  import Ecto.Changeset

  @categories ~w(alimentacao_saudavel hidratacao gasto_calorico sono atividade_fisica)

  schema "habits" do
    field :name, :string
    field :description, :string
    field :category, :string
    field :points, :integer

    belongs_to :user, EcoHabits.Accounts.User

    timestamps()
  end

  def changeset(habit, attrs) do
    habit
    |> cast(attrs, [:name, :description, :category, :points])
    |> validate_required([:name, :description, :category, :points, :user_id])
    |> validate_inclusion(:category, @categories)
    |> validate_number(:points, greater_than: 0)
  end

  def categories, do: @categories
end
