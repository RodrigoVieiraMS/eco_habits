defmodule EcoHabits.Habits do
  import Ecto.Query, warn: false

  alias EcoHabits.Accounts.User
  alias EcoHabits.Habits.Habit
  alias EcoHabits.Repo

  def list_habits(%User{} = user, category \\ "all") do
    Habit
    |> where([habit], habit.user_id == ^user.id)
    |> maybe_filter_category(category)
    |> order_by([habit], desc: habit.inserted_at)
    |> Repo.all()
  end

  def get_habit!(%User{} = user, id) do
    Repo.get_by!(Habit, id: id, user_id: user.id)
  end

  def create_habit(%User{} = user, attrs) do
    %Habit{user_id: user.id}
    |> Habit.changeset(attrs)
    |> Repo.insert()
  end

  def update_habit(%User{} = user, %Habit{} = habit, attrs) do
    if habit.user_id == user.id do
      habit
      |> Habit.changeset(attrs)
      |> Repo.update()
    else
      {:error, :unauthorized}
    end
  end

  def delete_habit(%User{} = user, %Habit{} = habit) do
    if habit.user_id == user.id do
      Repo.delete(habit)
    else
      {:error, :unauthorized}
    end
  end

  def change_habit(%Habit{} = habit, attrs \\ %{}) do
    Habit.changeset(habit, attrs)
  end

  def categories, do: Habit.categories()

  def total_points(%User{} = user) do
    Habit
    |> where([habit], habit.user_id == ^user.id)
    |> select([habit], sum(habit.points))
    |> Repo.one()
    |> Kernel.||(0)
  end

  defp maybe_filter_category(query, category) when category in ["", nil, "all"], do: query

  defp maybe_filter_category(query, category) do
    if category in categories() do
      where(query, [habit], habit.category == ^category)
    else
      query
    end
  end
end
