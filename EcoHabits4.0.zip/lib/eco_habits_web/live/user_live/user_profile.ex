defmodule EcoHabitsWeb.UserProfile do
  use EcoHabitsWeb, :live_view

  alias EcoHabits.Repo

  @impl true
  def mount(_params, _session, %{assigns: %{current_scope: %{user: user}}} = socket) do
    {:ok,
     socket
     |> assign(:user, user)
     |> assign(
       :form,
       to_form(%{
         "name" => user.name || "",
         "bio" => user.bio || ""
       })
     )}
  end

  @impl true
  def handle_event("save", %{"profile" => params}, socket) do
    user = socket.assigns.user

    changeset =
      Ecto.Changeset.change(user, %{
        name: params["name"],
        bio: params["bio"]
      })

    case Repo.update(changeset) do
      {:ok, updated_user} ->
        {:noreply,
         socket
         |> assign(:user, updated_user)
         |> put_flash(:info, "Perfil atualizado com sucesso!")}

      {:error, _changeset} ->
        {:noreply, put_flash(socket, :error, "Erro ao atualizar perfil")}
    end
  end

  @impl true
  def render(assigns) do
    ~H"""
    <Layouts.app flash={@flash} current_scope={@current_scope}>
      <div class="max-w-3xl mx-auto mt-10">
        <div class="bg-base-200 p-8 rounded-xl shadow">
          <h1 class="text-3xl font-bold mb-6">Meu Perfil</h1>

          <div class="mb-4"><strong>Email:</strong> {@user.email}</div>

          <div class="mb-4"><strong>Pontuação Total:</strong> {@user.total_points || 0}</div>

          <.form
            for={@form}
            as={:profile}
            phx-submit="save"
          >
            <.input
              field={@form[:name]}
              type="text"
              label="Nome"
            />
            <.input
              field={@form[:bio]}
              type="textarea"
              label="Biografia"
            /> <.button class="btn btn-primary mt-4">Salvar Perfil</.button>
          </.form>
        </div>
      </div>
    </Layouts.app>
    """
  end
end
