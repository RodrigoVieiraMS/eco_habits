defmodule EcoHabitsWeb.DashboardLive do
  use EcoHabitsWeb, :live_view

  def render(assigns) do
    ~H"""
    <div class="max-w-4xl mx-auto">
      <div class="bg-gradient-to-br from-emerald-600 to-teal-700 text-white rounded-2xl p-8 shadow-md mb-8">
        <h2 class="text-3xl font-bold mb-2">Bem-vindo ao Painel EcoHabits!</h2>

        <p class="text-emerald-100 max-w-xl">
          Este é o espaço central do nosso projeto. Escolha uma das opções abaixo⬇️
        </p>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div class="bg-gray-900 p-6 rounded-xl border border-gray-600 shadow-sm flex flex-col justify-between">
          <div>
            <h3 class="text-lg font-bold text-white mb-2">👤 Perfil</h3>

            <p class="text-gray-400 text-sm mb-4">
              Gerencie os detalhes do seu perfil e veja quantos pontos você possui!
            </p>
          </div>

          <.link
            navigate={~p"/users/profile"}
            class="mt-4 inline-flex items-center justify-center gap-2 rounded-xl border border-emerald-500 bg-emerald-900/40 px-4 py-2.5 text-sm font-semibold text-emerald-300 hover:bg-emerald-800/60 transition-colors"
          >
            Acessar Seu Perfil 🔗
          </.link>
        </div>

        <div class="bg-gray-900 p-6 rounded-xl border border-gray-600 shadow-sm flex flex-col justify-between hover:border-blue-500 transition-colors">
          <div>
            <div class="flex items-center space-x-2 mb-2">
              <span class="text-xl">📊</span>
              <h3 class="text-lg font-bold text-white">Painel B</h3>
            </div>

            <p class="text-gray-400 text-sm mb-4">
              Cadastre, filtre, edite e acompanhe seus hábitos sustentáveis.
            </p>
          </div>

          <.link
            navigate={~p"/habits"}
            class="mt-4 inline-flex items-center justify-center gap-2 rounded-xl border border-blue-500 bg-blue-900/40 px-4 py-2.5 text-sm font-semibold text-blue-300 hover:bg-blue-800/60 transition-colors"
          >
            Acessar hábitos
          </.link>
        </div>

        <div class="bg-gray-900 p-6 rounded-xl border border-gray-600 shadow-sm flex flex-col justify-between hover:border-purple-500 transition-colors">
          <div>
            <div class="flex items-center space-x-2 mb-2">
              <span class="text-xl">🌿</span>
              <h3 class="text-lg font-bold text-white">Painel C</h3>
            </div>

            <p class="text-gray-400 text-sm mb-4">bio parte c</p>
          </div>

          <.link
            navigate={~p"/users/register"}
            class="mt-4 inline-flex items-center justify-center gap-2 rounded-xl border border-purple-500 bg-purple-900/40 px-4 py-2.5 text-sm font-semibold text-purple-300 hover:bg-purple-800/60 transition-colors"
          >
            Acessar parte C
          </.link>
        </div>
      </div>
    </div>
    """
  end

  def mount(_params, _session, socket) do
    {:ok, socket}
  end
end
