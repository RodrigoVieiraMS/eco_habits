defmodule EcoHabitsWeb.HabitLive.Index do
  use EcoHabitsWeb, :live_view

  alias EcoHabits.Habits
  alias EcoHabits.Habits.Habit

  @impl true
  def mount(_params, _session, socket) do
    {:ok, assign(socket, :category, "all")}
  end

  @impl true
  def handle_params(params, _url, socket) do
    user = socket.assigns.current_scope.user
    category = Map.get(params, "category", socket.assigns.category || "all")

    socket =
      socket
      |> assign(:page_title, page_title(socket.assigns.live_action))
      |> assign(:category, category)
      |> assign(:filter_options, filter_options())
      |> assign(:habits, Habits.list_habits(user, category))
      |> apply_action(socket.assigns.live_action, params)

    {:noreply, socket}
  end

  @impl true
  def render(assigns) do
    ~H"""
    <div class="mx-auto max-w-5xl space-y-6">
      <div class="flex flex-col gap-4 border-b border-slate-200 pb-5 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <.link
            navigate={~p"/dashboard"}
            class="inline-flex items-center gap-2 text-sm text-slate-500 hover:text-slate-800"
          >
            <.icon name="hero-arrow-left" class="size-4" /> Voltar ao painel
          </.link>
          <h1 class="mt-3 text-2xl font-semibold tracking-tight text-slate-950">Gestão de hábitos</h1>
          <p class="mt-1 text-sm text-slate-600">
            Cadastre, filtre e acompanhe seus hábitos em um só lugar.
          </p>
        </div>

        <.link
          patch={~p"/habits/new"}
          class="inline-flex items-center justify-center gap-2 rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-semibold text-white hover:bg-slate-800"
        >
          <.icon name="hero-plus" class="size-4" /> Novo hábito
        </.link>
      </div>

      <div class="flex flex-wrap gap-2">
        <.link
          :for={{label, value} <- @filter_options}
          patch={~p"/habits?category=#{value}"}
          class={[
            "rounded-lg border px-3 py-2 text-sm font-medium transition",
            @category == value && "border-slate-900 bg-slate-900 text-white",
            @category != value && "border-slate-200 bg-white text-slate-700 hover:bg-slate-50"
          ]}
        >
          {label}
        </.link>
      </div>

      <div :if={@live_action in [:new, :edit]}>
        <.live_component
          module={EcoHabitsWeb.HabitLive.FormComponent}
          id={@habit.id || :new}
          title={@page_title}
          action={@live_action}
          habit={@habit}
          current_scope={@current_scope}
          patch={~p"/habits?category=#{@category}"}
        />
      </div>

      <div class="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
        <div class="flex items-center justify-between border-b border-slate-200 px-5 py-4">
          <div>
            <h2 class="text-sm font-semibold text-slate-900">Hábitos cadastrados</h2>
            <p class="text-sm text-slate-500">{length(@habits)} registro(s)</p>
          </div>
        </div>

        <div class="overflow-x-auto">
          <table class="min-w-full divide-y divide-slate-200">
            <thead class="bg-slate-50">
              <tr>
                <th class="px-5 py-3 text-left text-xs font-semibold uppercase text-slate-500">
                  Nome
                </th>
                <th class="px-5 py-3 text-left text-xs font-semibold uppercase text-slate-500">
                  Categoria
                </th>
                <th class="px-5 py-3 text-left text-xs font-semibold uppercase text-slate-500">
                  Pontos
                </th>
                <th class="px-5 py-3 text-right text-xs font-semibold uppercase text-slate-500">
                  Ações
                </th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              <tr :for={habit <- @habits} id={"habit-#{habit.id}"} class="hover:bg-slate-50">
                <td class="px-5 py-4">
                  <p class="font-medium text-slate-950">{habit.name}</p>
                  <p class="mt-1 text-sm text-slate-500">{habit.description}</p>
                </td>
                <td class="px-5 py-4 text-sm text-slate-700">{category_label(habit.category)}</td>
                <td class="px-5 py-4 text-sm font-semibold text-slate-900">{habit.points} pts</td>
                <td class="px-5 py-4">
                  <div class="flex justify-end gap-2 text-sm">
                    <.link navigate={~p"/habits/#{habit}"} class="text-slate-600 hover:text-slate-900">
                      Ver
                    </.link>
                    <.link
                      patch={~p"/habits/#{habit}/edit?category=#{@category}"}
                      class="text-slate-600 hover:text-slate-900"
                    >
                      Editar
                    </.link>
                    <.link
                      phx-click={
                        JS.push("delete", value: %{id: habit.id}) |> hide("#habit-#{habit.id}")
                      }
                      data-confirm="Remover este hábito?"
                      class="text-red-600 hover:text-red-700"
                    >
                      Excluir
                    </.link>
                  </div>
                </td>
              </tr>
              <tr :if={@habits == []}>
                <td colspan="4" class="px-5 py-10 text-center text-sm text-slate-500">
                  Nenhum hábito encontrado para este filtro.
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    """
  end

  @impl true
  def handle_event("delete", %{"id" => id}, socket) do
    user = socket.assigns.current_scope.user
    habit = Habits.get_habit!(user, id)
    {:ok, _} = Habits.delete_habit(user, habit)

    {:noreply, assign(socket, :habits, Habits.list_habits(user, socket.assigns.category))}
  end

  @impl true
  def handle_info({EcoHabitsWeb.HabitLive.FormComponent, {:saved, _habit}}, socket) do
    user = socket.assigns.current_scope.user
    {:noreply, assign(socket, :habits, Habits.list_habits(user, socket.assigns.category))}
  end

  defp apply_action(socket, :edit, %{"id" => id}) do
    assign(socket, :habit, Habits.get_habit!(socket.assigns.current_scope.user, id))
  end

  defp apply_action(socket, :new, _params), do: assign(socket, :habit, %Habit{})
  defp apply_action(socket, :index, _params), do: assign(socket, :habit, nil)

  defp page_title(:new), do: "Novo hábito"
  defp page_title(:edit), do: "Editar hábito"
  defp page_title(:index), do: "Gestão de hábitos"

  defp filter_options do
    [
      {"Todos", "all"},
      {"Alimentação Saudável", "alimentacao_saudavel"},
      {"Hidratação", "hidratacao"},
      {"Gasto Calórico", "gasto_calorico"},
      {"Sono", "sono"},
      {"Atividade Física", "atividade_fisica"}
    ]
  end

  defp category_label("alimentacao_saudavel"), do: "Alimentação Saudável"
  defp category_label("hidratacao"), do: "Hidratação"
  defp category_label("gasto_calorico"), do: "Gasto Calórico"
  defp category_label("sono"), do: "Sono"
  defp category_label("atividade_fisica"), do: "Atividade Física"
  defp category_label(category), do: category
end
