defmodule EcoHabitsWeb.HabitLive.Show do
  use EcoHabitsWeb, :live_view

  alias EcoHabits.Habits

  @impl true
  def handle_params(%{"id" => id}, _url, socket) do
    habit = Habits.get_habit!(socket.assigns.current_scope.user, id)

    {:noreply,
     socket
     |> assign(:page_title, "Visualizar hábito")
     |> assign(:habit, habit)}
  end

  @impl true
  def render(assigns) do
    ~H"""
    <div class="mx-auto max-w-3xl space-y-6">
      <div class="flex flex-col gap-4 border-b border-slate-200 pb-5 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <.link
            navigate={~p"/habits"}
            class="inline-flex items-center gap-2 text-sm text-slate-500 hover:text-slate-800"
          >
            <.icon name="hero-arrow-left" class="size-4" /> Voltar para hábitos
          </.link>
          <h1 class="mt-3 text-2xl font-semibold tracking-tight text-slate-950">{@habit.name}</h1>
          <p class="mt-1 text-sm text-slate-600">Detalhes do hábito cadastrado.</p>
        </div>

        <.link
          patch={~p"/habits/#{@habit}/show/edit"}
          class="inline-flex items-center justify-center gap-2 rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-semibold text-white hover:bg-slate-800"
        >
          <.icon name="hero-pencil-square" class="size-4" /> Editar
        </.link>
      </div>

      <div :if={@live_action == :edit}>
        <.live_component
          module={EcoHabitsWeb.HabitLive.FormComponent}
          id={@habit.id}
          title="Editar hábito"
          action={:edit}
          habit={@habit}
          current_scope={@current_scope}
          patch={~p"/habits/#{@habit}"}
        />
      </div>

      <div class="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <dl class="space-y-5">
          <div>
            <dt class="text-sm font-medium text-slate-500">Descrição</dt>
            <dd class="mt-1 text-slate-900">{@habit.description}</dd>
          </div>
          <div>
            <dt class="text-sm font-medium text-slate-500">Categoria</dt>
            <dd class="mt-1 text-slate-900">{category_label(@habit.category)}</dd>
          </div>
          <div>
            <dt class="text-sm font-medium text-slate-500">Pontuação</dt>
            <dd class="mt-1 text-xl font-semibold text-slate-950">{@habit.points} pts</dd>
          </div>
        </dl>
      </div>
    </div>
    """
  end

  @impl true
  def handle_info({EcoHabitsWeb.HabitLive.FormComponent, {:saved, habit}}, socket) do
    {:noreply, assign(socket, :habit, habit)}
  end

  defp category_label("alimentacao_saudavel"), do: "Alimentação Saudável"
  defp category_label("hidratacao"), do: "Hidratação"
  defp category_label("gasto_calorico"), do: "Gasto Calórico"
  defp category_label("sono"), do: "Sono"
  defp category_label("atividade_fisica"), do: "Atividade Física"
  defp category_label(category), do: category
end
