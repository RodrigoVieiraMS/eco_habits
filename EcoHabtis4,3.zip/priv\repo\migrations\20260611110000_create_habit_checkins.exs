defmodule EcoHabits.Repo.Migrations.CreateHabitCheckins do
  use Ecto.Migration

  def change do
    create table(:habit_checkins) do
      add :points, :integer, null: false
      add :completed_at, :utc_datetime_usec, null: false

      add :user_id,
          references(:users, on_delete: :delete_all),
          null: false

      add :habit_id,
          references(:habits, on_delete: :delete_all),
          null: false

      timestamps(type: :utc_datetime_usec)
    end

    create index(:habit_checkins, [:user_id])
    create index(:habit_checkins, [:habit_id])
    create index(:habit_checkins, [:completed_at])
  end
end
