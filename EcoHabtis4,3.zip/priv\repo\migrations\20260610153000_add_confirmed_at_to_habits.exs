defmodule EcoHabits.Repo.Migrations.AddConfirmedAtToHabits do
  use Ecto.Migration

  def change do
    alter table(:habits) do
      add :confirmed_at, :utc_datetime_usec
    end

    create index(:habits, [:confirmed_at])
  end
end
