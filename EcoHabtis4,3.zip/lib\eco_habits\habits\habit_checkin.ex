defmodule EcoHabits.Habits.HabitCheckin do
  use Ecto.Schema
  import Ecto.Changeset

  schema "habit_checkins" do
    field :points, :integer
    field :completed_at, :utc_datetime_usec

    belongs_to :user, EcoHabits.Accounts.User
    belongs_to :habit, EcoHabits.Habits.Habit

    timestamps(type: :utc_datetime_usec)
  end

  def changeset(checkin, attrs) do
    checkin
    |> cast(attrs, [:user_id, :habit_id, :points, :completed_at])
    |> validate_required([:user_id, :habit_id, :points, :completed_at])
    |> validate_number(:points, greater_than: 0)
  end
end
