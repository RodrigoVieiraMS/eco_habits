defmodule EcoHabits.Habits do
  import Ecto.Query, warn: false

  alias EcoHabits.Accounts.User
  alias EcoHabits.Habits.{Habit, HabitCheckin}
  alias EcoHabits.Repo
  alias Phoenix.PubSub

  def list_habits(%User{} = user, category \\ "all") do
    Habit
    |> where([habit], habit.user_id == ^user.id)
    |> maybe_filter_category(category)
    |> order_by([habit], desc: habit.inserted_at)
    |> Repo.all()
  end

  def list_checkins(%User{} = user, category \\ "all") do
    HabitCheckin
    |> join(:inner, [checkin], habit in assoc(checkin, :habit))
    |> where([checkin, _habit], checkin.user_id == ^user.id)
    |> maybe_filter_checkin_category(category)
    |> preload([_checkin, habit], habit: habit)
    |> order_by([checkin, _habit], desc: checkin.completed_at)
    |> Repo.all()
  end

  def list_confirmed_habits(%User{} = user, category \\ "all") do
    list_checkins(user, category)
    |> Enum.map(& &1.habit)
  end

  def confirmed_habit_ids(%User{} = user, category \\ "all") do
    list_checkins(user, category)
    |> Enum.map(& &1.habit_id)
    |> MapSet.new()
  end

  def confirmed?(%User{} = user, %Habit{} = habit, category \\ "all") do
    MapSet.member?(confirmed_habit_ids(user, category), habit.id)
  end

  def get_habit!(%User{} = user, id) do
    Repo.get_by!(Habit, id: id, user_id: user.id)
  end

  def create_habit(%User{} = user, attrs) do
    %Habit{user_id: user.id, points: 0}
    |> Habit.changeset(attrs)
    |> Repo.insert()
    |> broadcast_user_event(user.id)
  end

  def update_habit(%User{} = user, %Habit{} = habit, attrs) do
    if habit.user_id == user.id do
      habit
      |> Habit.changeset(attrs)
      |> Repo.update()
      |> broadcast_user_event(user.id)
    else
      {:error, :unauthorized}
    end
  end

  def delete_habit(%User{} = user, %Habit{} = habit) do
    if habit.user_id == user.id do
      Repo.delete(habit)
      |> broadcast_user_event(user.id)
    else
      {:error, :unauthorized}
    end
  end

  def change_habit(%Habit{} = habit, attrs \\ %{}) do
    Habit.changeset(habit, attrs)
  end

  def confirm_habit(%User{} = user, %Habit{} = habit) do
    if habit.user_id == user.id do
      %HabitCheckin{}
      |> HabitCheckin.changeset(%{
        user_id: user.id,
        habit_id: habit.id,
        points: 10,
        completed_at: DateTime.utc_now(:microsecond)
      })
      |> Repo.insert()
      |> broadcast_user_event(user.id)
    else
      {:error, :unauthorized}
    end
  end

  def categories, do: Habit.categories()

  def total_points(%User{} = user) do
    HabitCheckin
    |> where([checkin], checkin.user_id == ^user.id)
    |> select([checkin], sum(checkin.points))
    |> Repo.one()
    |> Kernel.||(0)
  end

  defp maybe_filter_category(query, "all"), do: query
  defp maybe_filter_category(query, nil), do: query
  defp maybe_filter_category(query, ""), do: query

  defp maybe_filter_category(query, category) do
    if category in categories() do
      where(query, [habit], habit.category == ^category)
    else
      query
    end
  end

  defp maybe_filter_checkin_category(query, "all"), do: query
  defp maybe_filter_checkin_category(query, nil), do: query
  defp maybe_filter_checkin_category(query, ""), do: query

  defp maybe_filter_checkin_category(query, category) do
    if category in categories() do
      where(query, [_checkin, habit], habit.category == ^category)
    else
      query
    end
  end

  defp broadcast_user_event({:ok, habit_or_checkin}, user_id) do
    PubSub.broadcast(EcoHabits.PubSub, topic(user_id), {:habit_changed, habit_or_checkin})
    {:ok, habit_or_checkin}
  end

  defp broadcast_user_event({:error, _} = error, _user_id), do: error

  defp topic(user_id), do: "habits:#{user_id}"
end
