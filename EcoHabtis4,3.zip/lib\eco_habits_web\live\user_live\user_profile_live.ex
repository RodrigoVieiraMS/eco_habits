defmodule EcoHabitsWeb.UserProfileLive do
  use EcoHabitsWeb, :live_view

  import EcoHabitsWeb.CoreComponents
  alias EcoHabits.Accounts
  alias EcoHabits.Habits

  def render(assigns) do
    ~H"""
    <div class="max-w-2xl mx-auto">
      <%!-- Botão Voltar --%>
      <div class="mb-4">
        <.link
          navigate={~p"/dashboard"}
          class="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-gray-700"
        >
          <.icon name="hero-arrow-left" class="size-4" /> Voltar
        </.link>
      </div>

      <div class="border-b border-gray-200 pb-5 mb-6">
        <h2 class="text-2xl font-bold leading-7 text-gray-950 sm:text-3xl tracking-tight">
          Meu Perfil Sustentável
        </h2>

        <p class="mt-1 text-sm leading-6 text-gray-500">
          Gerencie suas informações e acompanhe seu impacto no EcoHabits.
        </p>
      </div>
      <%!-- Infobox de sucesso --%>
      <%= if @saved do %>
        <div class="mb-6 flex items-center gap-3 rounded-xl border border-emerald-300 bg-emerald-50 px-4 py-3 text-emerald-800">
          <.icon name="hero-check-circle" class="size-5 text-emerald-600" />
          <span class="text-sm font-medium">Perfil atualizado com sucesso!</span>
        </div>
      <% end %>
      <%!-- Prévia do perfil --%>
      <div class="mb-8 flex flex-col items-center gap-2 rounded-xl border border-blue-900 bg-blue-900 py-6">
        <div class="size-24 rounded-full bg-gray-300 flex items-center justify-center ring-4 ring-blue-700 overflow-hidden">
          <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" class="size-24">
            <circle cx="50" cy="38" r="22" fill="#9ca3af" />
            <ellipse cx="50" cy="85" rx="32" ry="22" fill="#9ca3af" />
          </svg>
        </div>

        <p class="text-lg font-semibold text-white">{@display_name}</p>

        <%= if @display_bio != "" do %>
          <p class="text-sm text-blue-200 text-center px-6">{@display_bio}</p>
        <% end %>
      </div>

      <div class="bg-emerald-50 border border-emerald-200 rounded-xl p-6 mb-8 flex items-center justify-between">
        <div>
          <h3 class="text-lg font-semibold text-emerald-900">Sua Pontuação Total</h3>

          <p class="text-sm text-emerald-700">Acumulada através de hábitos saudáveis.</p>
        </div>

        <div class="bg-emerald-600 text-white font-bold text-3xl px-6 py-3 rounded-xl shadow-inner">
          {@total_points} pts
        </div>
      </div>

      <.simple_form for={@form} id="profile_form" phx-submit="save_profile" phx-change="validate">
        <div class="space-y-6">
          <.input field={@form[:name]} type="text" label="Nome Completo" required />
          <.input
            field={@form[:bio]}
            type="textarea"
            label="Sua Bio (Conte sua jornada sustentável...)"
            placeholder="Ex: Entusiasta da reciclagem e ciclista urbano."
            rows={4}
          />
        </div>

        <:actions>
          <.button
            phx-disable-with="Salvando..."
            class="w-full sm:w-auto bg-emerald-700 hover:bg-emerald-600 rounded-2xl px-8 py-3 text-base font-semibold"
          >
            Salvar Perfil
          </.button>
        </:actions>
      </.simple_form>
    </div>
    """
  end

  def mount(_params, _session, socket) do
    user = socket.assigns.current_scope.user

    name = user.name || "Usuário Eco"
    bio = user.bio || ""
    total_points = Habits.total_points(user)

    form = to_form(%{"name" => name, "bio" => bio})

    {:ok,
     assign(socket,
       form: form,
       total_points: total_points,
       display_name: name,
       display_bio: bio,
       saved_name: name,
       saved_bio: bio,
       saved: false
     )}
  end

  def handle_event("validate", %{"name" => name, "bio" => bio}, socket) do
    form = to_form(%{"name" => name, "bio" => bio})
    {:noreply, assign(socket, form: form, display_name: name, display_bio: bio, saved: false)}
  end

  def handle_event("save_profile", %{"name" => name, "bio" => bio}, socket) do
    user = socket.assigns.current_scope.user
    changed = name != socket.assigns.saved_name or bio != socket.assigns.saved_bio

    if changed do
      case Accounts.update_user_profile(user, %{"name" => name, "bio" => bio}) do
        {:ok, _updated_user} ->
          form = to_form(%{"name" => name, "bio" => bio})
          total_points = Habits.total_points(user)

          {:noreply,
           assign(socket,
             form: form,
             total_points: total_points,
             display_name: name,
             display_bio: bio,
             saved_name: name,
             saved_bio: bio,
             saved: true
           )}

        {:error, _changeset} ->
          {:noreply, put_flash(socket, :error, "Erro ao salvar perfil.")}
      end
    else
      {:noreply, assign(socket, saved: false)}
    end
  end
end
