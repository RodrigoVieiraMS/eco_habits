defmodule EcoHabitsWeb.HabitLive.FormComponent do
  use EcoHabitsWeb, :live_component

  alias EcoHabits.Habits

  @impl true
  def update(%{habit: habit} = assigns, socket) do
    changeset = Habits.change_habit(habit)

    {:ok,
     socket
     |> assign(assigns)
     |> assign(:categories, category_options())
     |> assign_form(changeset)}
  end

  @impl true
  def render(assigns) do
    ~H"""
    <div class="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
      <div class="pb-4">
        <h2 class="text-lg font-semibold text-black">{@title}</h2>
        <p class="text-sm text-slate-600">Preencha os dados do hábito.</p>
      </div>

      <.simple_form
        for={@form}
        id="habit-form"
        phx-target={@myself}
        phx-change="validate"
        phx-submit="save"
      >
        <div class="grid gap-4 sm:grid-cols-2">
          <.input
            field={@form[:name]}
            type="text"
            label="Nome"
            required
            class="w-full rounded-xl border border-slate-300 bg-white text-black shadow-none"
          />
          <.input
            field={@form[:category]}
            type="select"
            label="Categoria"
            prompt="Selecione uma categoria"
            options={@categories}
            required
            class="w-full rounded-xl border border-slate-300 bg-white text-black shadow-none"
          />
        </div>

        <.input
          field={@form[:description]}
          type="textarea"
          label="Descrição"
          rows="4"
          required
          class="w-full rounded-xl border border-slate-300 bg-white text-black shadow-none"
        />

        <:actions>
          <div class="flex w-full flex-col-reverse gap-3 sm:flex-row sm:justify-end">
            <.link
              patch={@patch}
              class="inline-flex items-center justify-center rounded-xl border border-slate-300 px-4 py-2.5 text-sm font-medium text-slate-700 hover:bg-slate-50"
            >
              Cancelar
            </.link>
            <button
              type="submit"
              phx-disable-with="Salvando..."
              class="inline-flex items-center justify-center rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-semibold text-white hover:bg-slate-800"
            >
              Salvar hábito
            </button>
          </div>
        </:actions>
      </.simple_form>
    </div>
    """
  end

  @impl true
  def handle_event("validate", %{"habit" => habit_params}, socket) do
    changeset =
      socket.assigns.habit
      |> Habits.change_habit(habit_params)
      |> Map.put(:action, :validate)

    {:noreply, assign_form(socket, changeset)}
  end

  def handle_event("save", %{"habit" => habit_params}, socket) do
    save_habit(socket, socket.assigns.action, habit_params)
  end

  defp save_habit(socket, :edit, habit_params) do
    user = socket.assigns.current_scope.user

    case Habits.update_habit(user, socket.assigns.habit, habit_params) do
      {:ok, habit} ->
        notify_parent({:saved, habit})

        {:noreply,
         socket
         |> put_flash(:info, "Hábito atualizado com sucesso.")
         |> push_patch(to: socket.assigns.patch)}

      {:error, %Ecto.Changeset{} = changeset} ->
        {:noreply, assign_form(socket, changeset)}

      {:error, :unauthorized} ->
        {:noreply, put_flash(socket, :error, "Você não pode editar este hábito.")}
    end
  end

  defp save_habit(socket, :new, habit_params) do
    user = socket.assigns.current_scope.user

    case Habits.create_habit(user, habit_params) do
      {:ok, habit} ->
        notify_parent({:saved, habit})

        {:noreply,
         socket
         |> put_flash(:info, "Hábito criado com sucesso.")
         |> push_patch(to: socket.assigns.patch)}

      {:error, %Ecto.Changeset{} = changeset} ->
        {:noreply, assign_form(socket, changeset)}
    end
  end

  defp assign_form(socket, %Ecto.Changeset{} = changeset) do
    assign(socket, :form, to_form(changeset))
  end

  defp category_options do
    [
      {"Alimentação", "alimentacao"},
      {"Transporte", "transporte"},
      {"Energia", "energia"},
      {"Água", "agua"},
      {"Resíduos", "residuos"}
    ]
  end

  defp notify_parent(msg), do: send(self(), {__MODULE__, msg})
end
