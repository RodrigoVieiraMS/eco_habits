defmodule EcoHabits.Habits.Habit do
  use Ecto.Schema
  import Ecto.Changeset

  @categories ~w(alimentacao transporte energia agua residuos)

  schema "habits" do
    field :name, :string
    field :description, :string
    field :category, :string
    field :points, :integer

    belongs_to :user, EcoHabits.Accounts.User
    has_many :habit_checkins, EcoHabits.Habits.HabitCheckin

    timestamps()
  end

  def changeset(habit, attrs) do
    habit
    |> cast(attrs, [:name, :description, :category, :points])
    |> validate_required([:name, :description, :category, :user_id])
    |> validate_inclusion(:category, @categories)
  end

  def categories, do: @categories
end
