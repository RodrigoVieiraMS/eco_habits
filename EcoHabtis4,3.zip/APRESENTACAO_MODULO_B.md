# Apresentação - Módulo B EcoHabits

## Slide 1 - Título

**EcoHabits - Módulo B**

Gerenciamento de hábitos com foco em organização, confirmação e acompanhamento de pontuação.

## Slide 2 - Objetivo

O objetivo do Módulo B é permitir que o usuário:

- cadastre hábitos;
- filtre os hábitos por categoria;
- confirme hábitos realizados;
- acompanhe os pontos ganhos;
- visualize os check-ins recentes.

## Slide 3 - Estrutura utilizada

O módulo foi desenvolvido com a stack original do projeto:

- Elixir;
- Phoenix;
- LiveView;
- Ecto;
- PostgreSQL / Supabase.

## Slide 4 - O que foi entregue

Foi feita uma refatoração visual e funcional na área de hábitos:

- interface mais limpa;
- organização mais clara;
- texto do topo ajustado;
- subtítulo definido como `Colocar Habito`;
- confirmação de hábitos preservada;
- feed de check-ins exibido de forma separada;
- pontuação total calculada a partir dos check-ins confirmados.

## Slide 5 - Fluxo do usuário

1. O usuário entra no Módulo B.
2. Cadastra um hábito.
3. Visualiza o hábito na lista.
4. Clica em **Confirmar** quando realiza a ação.
5. O check-in é registrado.
6. Os pontos são somados ao perfil.
7. O histórico aparece no feed de atividades.

## Slide 6 - Pontos fortes da solução

- mantém a arquitetura do Phoenix;
- separa bem cadastro e confirmação;
- usa LiveView para atualização de tela;
- organiza os dados por contexto;
- mantém a regra de acesso do usuário;
- deixa a interface mais próxima de uma aplicação real.

## Slide 7 - Resultado final

O Módulo B ficou mais apresentável para demonstração acadêmica, com:

- leitura simples;
- visual mais profissional;
- comportamento consistente;
- apresentação clara do que foi feito.

## Slide 8 - Frase de encerramento

**EcoHabits - Módulo B**

Gestão de hábitos com confirmação, pontuação e acompanhamento em tempo real.

